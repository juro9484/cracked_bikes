# Here, 'scdev' is the host with Kafka, Redis, and Zookeeper
REDIS_HOST = 'localhost'
KAFKA_HOSTS = 'localhost:9092'
ZOOKEEPER_HOSTS = 'localhost:2181'
SC_LOG_LEVEL="DEBUG"