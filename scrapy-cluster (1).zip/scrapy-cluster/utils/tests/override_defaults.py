STRING = "my stuff"
MY_STRING = "cool"
DICT = {
    "value": "override",
    "append": "value"
}
NEW_DICT = {
    "other": "stuff"
}
NEW_LIST = ['item1']
