__version__ = '1.3.0dev6'
VERSION = tuple(int(x) for x in __version__.split('.'))
