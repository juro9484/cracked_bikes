# Here, 'scdev' is the host with Kafka and Redis
REDIS_HOST = 'localhost'
KAFKA_HOSTS = 'localhost:9092'
KAFKA_CONSUMER_TIMEOUT = -1