ELK
===

This folder houses sample files used when integrating Scrapy Cluster with Elasticsearch, Logstash and Kibana. For more information please see Scrapy Cluster's official Documentation.

Last tested on Nov 27, 2016 with:

* Elasticsearch 5.0

* Logstash 5.0

* Kibana 5.0